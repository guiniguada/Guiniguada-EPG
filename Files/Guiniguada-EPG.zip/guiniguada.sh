#!/bin/sh

python guiniguada.pyc

python guiaTVXml.pyc
